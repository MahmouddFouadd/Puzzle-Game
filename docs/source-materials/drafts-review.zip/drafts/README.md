# Story audit draft pack

This is an editorial review pack, not an import or publish package. It summarizes a supplied read-only story snapshot and keeps generated question text and missing-photo prompts as drafts. No story data, images, question rows, puzzle pieces, or mappings were changed.

| File | Purpose |
|---|---|
| [Consolidated story inventory](./live-story-content-audit.md) | 14 stories, source-snapshot status labels, question/piece/mapping gaps, and content-quality flags. |
| [Missing-photo prompt pack](./missing-photo-prompts.md) | 18 suggested image prompts for the six narrative-backed stories with no image records in the source snapshot. |

## Per-story reports

| Story | Draft review |
|---|---|
| 01 — Test | [Open report](./story-01.md) |
| 02 — Tese | [Open report](./story-02.md) |
| 03 — Ali Baba / Juha | [Open report](./story-03.md) |
| 04 — Juha and the donkey | [Open report](./story-04.md) |
| 05 — Layla's small gift | [Open report](./story-05.md) |
| 06 — Adam respects differences | [Open report](./story-06.md) |
| 07 — The ant that asked for help | [Open report](./story-07.md) |
| 08 — Marwan and the library key | [Open report](./story-08.md) |
| 09 — The tortoise and beautiful patience | [Open report](./story-09.md) |
| 10 — Noor chooses wisely | [Open report](./story-10.md) |
| 11 — Two friends on a rainy day | [Open report](./story-11.md) |
| 12 — Honesty is an everlasting treasure | [Open report](./story-12.md) |
| 13 — Fahd's trip to activity | [Open report](./story-13.md) |
| 14 — Salim and the thirsty tree | [Open report](./story-14.md) |

## Editorial caveats

There are 228 proposed questions across the per-story reviews and 18 photo prompts. Proposals are not persisted questions, verified answer keys, puzzle-piece mappings, images, or publication approvals. Test, Tese, and the combined Ali Baba/Juha story have no new-question proposals because their source narratives/scope do not support safe additions. Verify actual image files separately from image records and obtain human review before any later import, mapping, or publication.
