# Story-content inventory and audit (snapshot-only)

**Review scope:** 14 declared per-story draft reports, `story-01.md` through `story-14.md`, and their supplied structured summaries. This is a consolidated editorial inventory, not a live-system audit. All underlying inventories are read-only snapshots dated **2026-11-25** (some report metadata gives only the date; story 01 explicitly says “2026-11-25 read-only Supabase inventory”). They may be stale and must not be treated as current state. No live story/question/image/piece/mapping row query was made for this editorial inventory; a later read-only schema/security inventory is documented in `docs/DETECTIVE_MODE_PHASE0_AUDIT.md`. No production data was modified, no content was imported or published, and no application source was changed. **Nothing in this consolidation is import-ready, approved for publication, or evidence that a story is playable or publishable.**

“Existing questions” means question records reported in the supplied snapshot; “draft questions” means unpersisted editorial proposals in the individual audit. They are not interchangeable. Image-row counts describe records, not verified image files. For piece counts, `not reported` / `unavailable` means the snapshot did not supply a count; it does not mean zero. In several structured summaries, zero is an unavailable-count sentinel, explicitly not a verified zero. Mapping gaps below are numerical comparisons to configured pieces only where a configured-piece count was actually supplied; they do not establish a one-question-per-piece requirement or semantic suitability.

## Executive inventory

- **14 stories reviewed; 0 report failures.** All 14 declared report files were read. The supplied `Failures` list is empty; no story review was reported as failed. This does not remove the editorial holds or snapshot limitations noted below.
- **228 draft questions** are reported across the individual reports. These remain proposals only; they do not add to existing-question counts.
- **18 image records** are reported across eight stories. Six other stories have zero image records and substantive narratives; only those six belong in the separate missing-photo prompt pack.
- Among stories with an explicit configured-piece count, the reported configured/generated pairs are: 12/0, 8/8, 24/24, 48/48, 36/0, 36/0, 12/0, 36/0. The remaining six stories lack a reportable configured/generated count. Their structured zero sentinels are not evidence of actual zero pieces.
- Across all stories there are **32 existing questions** and **20 questions marked published in the supplied snapshots**. There are **20 approved mappings** recorded in total. These aggregate snapshot counts do not indicate present live state or content approval.
- Every deliverable and every proposed question remains a draft. Do not import, publish, or claim playability based on these reports.

## Story-by-story inventory

| # | Story (ID) | Story status (source snapshot)* | Narrative | Image records | Pieces configured / generated | Existing / published questions | Draft questions in report | Approved mappings; numerical gap vs configured pieces** |
|---:|---|---|---|---:|---:|---:|---:|---|
| 01 | Test (`da9c88c6-7ca1-410f-902c-c256eade8046`) | DRAFT | Absent | 1 | 12 / 0 | 0 / 0 | 0 | 0; gap 12 |
| 02 | Tese (`53a8c06c-579c-4a63-b6ab-20c902372d77`) | PUBLISHED | Absent | 2 | 8 / 8 | 8 / 8 | 0 | 8; gap 0 |
| 03 | علي بابا والكنز المخبأ وجحا والحمار (`f9eee5fc-d89d-4247-94eb-2c326f55bb62`) | DRAFT | Absent (`final_narrative: null`) | 2 | 24 / 24 | 12 / 12 | 0 | 12; gap 12 |
| 04 | جحا والحمار ورأي الناس (`d7055478-c449-418e-851c-3240b1f9b3a4`) | DRAFT | Present | 3 | 48 / 48 | 12 / 0 | 36 | 0; gap 48 |
| 05 | هدية ليلى الصغيرة (`195a4f79-1603-5bf5-befa-22f4b4f0e4fd`) | DRAFT | Present | 0 | Not reported / not reported | 0 / 0 | 12 | 0; not calculable |
| 06 | آدم يحترم الاختلاف (`4afc2af2-8912-5d6c-b2c7-82671d690053`) | DRAFT | Present | 3 | 36 / 0 | 0 / 0 | 36 | 0; gap 36 |
| 07 | النملة التي طلبت المساعدة (`5b130193-3176-5622-9280-b498f25efb29`) | DRAFT | Present | 0 | Not reported / not reported | 0 / 0 | 12 | 0; not calculable |
| 08 | مروان ومفتاح المكتبة (`6f4baa47-766c-56e8-b95e-ffd42984d0a2`) | DRAFT | Present | 0 | Not reported / not reported | 0 / 0 | 12 | 0; not calculable |
| 09 | السلحفاة والصبر الجميل (`7b62dc8e-787b-5bc1-bc78-694f47a272b1`) | DRAFT | Present | 0 | Not reported / not reported | 0 / 0 | 12 | 0; not calculable |
| 10 | نور تختار بحكمة (`9b999430-e4b1-5e94-a8be-a2a57716a548`) | DRAFT | Present | 0 | Not reported / not reported | 0 / 0 | 12 | 0; not calculable |
| 11 | صديقان في يوم المطر (`af3fab92-b8a7-5dfa-ab85-a530197a554b`) | DRAFT | Present | 3 | 36 / 0 | 0 / 0 | 36 | 0; gap 36 |
| 12 | الأمانة كنز لا يفنى (`beed3e5f-dfbc-537e-8488-ab0151424880`) | DRAFT | Present | 1 | 12 / 0 | 0 / 0 | 12 | 0; gap 12 |
| 13 | رحلة فهد إلى النشاط (`c5838cee-3f95-5209-a28a-7b84e22b0142`) | DRAFT | Present | 3 | 36 / 0 | 0 / 0 | 36 | 0; gap 36 |
| 14 | سليم والشجرة العطشى (`cab7818d-fd5d-584a-875a-ec7c331069bd`) | DRAFT | Present | 0 | Not reported / not reported | 0 / 0 | 12 | 0; not calculable |

\* Story status is copied from the supplied story snapshot: Tese (story 02) is `PUBLISHED`; stories 01 and 03–14 are `DRAFT`. Labels such as `draft_audit_complete`, `DRAFT_AUDIT_COMPLETED`, and “DRAFT audit” describe report/review state, not story status. These are snapshot facts, not a claim that this work published anything or that the content is currently valid; no content was changed.

\** For rows with a configured-piece count, “gap” is the arithmetic comparison between configured pieces and approved mappings reported. It is not a finding that every configured piece must have exactly one question/mapping. For stories 05, 07, 08, 09, 10, and 14, no count-based gap is calculable. The structured JSON zero values for configured/generated counts in these reports are unavailable/not-evidenced sentinels, not confirmed zero counts.

### Image-row distinction

**Image records exist** for stories 01, 02, 03, 04, 06, 11, 12, and 13. Their image-row total is 18. A record does not prove that its binary image file is retrievable, visible, appropriate, or complete; this caveat is particularly material for stories 01–03, 06, 11–13. **No image records are present in the supplied snapshots** for stories 05, 07, 08, 09, 10, and 14. Those six have substantive narrative content and are the only stories represented in [the missing-photo prompt pack](./missing-photo-prompts.md). The three prompts per such story are suggestions, not images, image rows, generated assets, or approvals. Test is not included because its narrative is absent; Tese and the combined Ali Baba/Juha story are not included because image records already exist.

### Piece, question, publication, and mapping interpretation

- Story 01 has 12 configured pieces and none generated: a reported 12-piece generation gap, alongside no questions and no mappings. Its sole image row is not a missing-image finding.
- Story 02 has 8 configured and 8 generated pieces, 8 existing/published questions, and 8 approved mappings. The numerical counts align, but neither story fit nor semantic mapping suitability is established.
- Story 03 has 24 configured/generated pieces, 12 existing/published questions, and 12 approved mappings. The report flags numerical gaps of 12 questions and 12 approved mappings relative to 24 configured pieces; one-to-one coverage and scene fit remain unverified.
- Story 04 has 48 configured/generated pieces, 12 existing but unpublished questions, 36 proposed questions, and zero approved mappings: a reported mapping gap of 48 against configured pieces. Its 36 suggestions do not constitute 36 approved questions or mappings.
- Story 06 has 36 configured pieces, zero generated, no existing questions or mappings, and 36 draft questions; reported generation and mapping gaps are each 36.
- Story 11 likewise has 36 configured, zero generated, no existing questions or mappings, and 36 draft questions; reported generation and mapping gaps are each 36.
- Story 12 has 12 configured, zero generated, no existing questions or mappings, and 12 draft questions; reported generation and mapping gaps are each 12.
- Story 13 has 36 configured, zero generated, no existing questions or mappings, and 36 draft questions; reported generation and mapping gaps are each 36.
- Stories 05, 07, 08, 09, 10, and 14 report no image rows, no existing/published questions, and no approved mappings, with 12 proposed questions apiece. Their configured/generated piece counts are unavailable, not known to be zero; piece-based question or mapping coverage cannot be calculated.

## Draft question materials included in the per-story reports

The exact draft question wording, answer choices/accepted answers, explanations, proposed difficulty, and conceptual scene targets remain in the linked detailed reports (`story-01.md`–`story-14.md`) in this same directory. The summaries below identify all reported question-draft material without turning it into an import package. Scene/image grouping is only conceptual unless expressly established as an existing record grouping in the source report; it is not a mapping approval.

| Story | Reported draft material (summary of proposed coverage) |
|---|---|
| Test | No question material. Narrative is absent and the title is placeholder-like; no facts are available to support question drafting. |
| Tese | No new questions. The title-specific rule prohibits additions, and narrative is absent; preserve the eight existing question/mapping records unchanged pending review. |
| علي بابا والكنز المخبأ وجحا والحمار | No new questions. The combined Ali Baba/Juha title is subject to the no-additions rule; narrative absent, scope/splitting decision required. |
| جحا والحمار ورأي الناس | 36 Arabic draft questions across the reported story sequence: journey/market and first criticism; the son riding and the second criticism; both riding, carrying the donkey, and the lesson about not pleasing everyone. The report also recommends editorial review of existing question wording. |
| هدية ليلى الصغيرة | 12 Arabic draft questions on Layla's coloring supplies and helping Samer, sharing her umbrella with Noor in the rain, and helping the apple seller. The scene targets correspond to three proposed, not existing, image scenes. |
| آدم يحترم الاختلاف | 36 Arabic draft questions on Adam welcoming Samer, their respectful conversation and differences; collaborative block-city building and tasks; sharing strengths, listening, and making a diverse garden picture. |
| النملة التي طلبت المساعدة | 12 Arabic draft questions on Noura finding a wheat grain, asking Sami and Luma for help, moving it past a branch, sharing it, and planting the grains. |
| مروان ومفتاح المكتبة | 12 Arabic draft questions on receiving and safeguarding the library key, opening the story cabinet and returning the key, then helping with library-loan cards and asking for help. |
| السلحفاة والصبر الجميل | 12 Arabic draft questions on Salma's goal of reaching the apple tree, resting and climbing the hill in stages, and reaching the tree and sharing the apple with friends. |
| نور تختار بحكمة | 12 Arabic draft questions on asking permission before opening art supplies, choosing the designated garden path, and sharing sweets thoughtfully. |
| صديقان في يوم المطر | 36 Arabic draft questions grouped conceptually into helping Adel under a shared umbrella; promising and taking turns to care for a mint seedling; and learning to check the soil and water thoughtfully. |
| الأمانة كنز لا يفنى | 12 Arabic draft questions on finding and returning Kareem's wallet, telling the truth, and later returning a found silver pen and agreeing how to handle lost property. One existing image row is recorded, but it does not establish that every proposed scene is depicted. |
| رحلة فهد إلى النشاط | 36 Arabic draft questions grouped around Fahd's healthy morning routine and breakfast; safe activity, water, and exercise at school; and dinner, evening routines, and early sleep. |
| سليم والشجرة العطشى | 12 Arabic draft questions about finding a thirsty olive tree, caring for it responsibly and conserving water, and seeing the tree recover while keeping the school garden clean. |

### Existing-content quality flags (read-only findings)

- **Test:** no narrative or description, title is placeholder-like, one image record titled “63226,” and zero generated pieces. No question-quality review is possible because there are no existing questions. Do not invent narrative or questions.
- **Tese:** no narrative/description. Eight existing MCQs are recorded in Arabic although the story language is recorded as English; question metadata is mixed (three `en`, five `ar`). The per-story report finds generic/vague wording, an unclear yes/no pattern, and a possible unsupported name reference; factual story fit cannot be checked without an approved narrative. Keep all existing rows and mappings unchanged.
- **Ali Baba/Juha combined story:** narrative absent and title combines two story scopes. Three existing true/false records directly conflict with their own explanations (thieves hidden in cotton bags vs jars; Qasim escaping easily vs being trapped; “open sesame” vs “open, O bread”). The report also flags the original-story thief-count question as unverifiable from the supplied narrative. Existing questions and mappings must remain unchanged pending narrative, scope, and editorial decisions.
- **جحا والحمار ورأي الناس:** the 12 existing questions are unpublished. The report identifies a question/answer mismatch in the item asking what Juha and his son did when both rode the donkey (stored answer describes passers-by's reaction); an imprecise reference to a word not literally in the narrative; and a vocabulary item whose context could be clearer. It notes some overlap in the lesson-focused questions, but no other definitive factual error from the supplied report.
- **Other stories:** no pre-existing question set is reported for stories 05–14 except the entries just described for story 04; where no existing questions are reported, there are no legacy question records to quality-review. This is not approval of the proposed drafts. All question drafts require human editorial review for factual grounding, language, age suitability, answer correctness, clarity, duplication, and scene fit.

## Exclusions, safeguards, and next steps

**No question additions are made for Test, Tese, or علي بابا والكنز المخبأ وجحا والحمار.** For Test and Tese, the titles and absent narratives do not support new questions (and Tese has an explicit title rule); for the combined Ali Baba/Juha title, the no-additions rule and unresolved narrative/scope prohibit additions. No proposed facts or scenes have been invented to fill those gaps.

Recommended sequence before any later administrative action:

1. Obtain a fresh, authorized snapshot/current-state check; these inventories are dated 2026-11-25 and may be stale.
2. Ask the content owner/editor to restore or approve missing narratives and resolve placeholder title/scope/language issues, especially Test, Tese, and the combined Ali Baba/Juha story.
3. Review all proposed Arabic drafts, and investigate the specific legacy-question quality flags above. Preserve existing records and mappings until authorized editorial approval.
4. Verify actual image files separately from image records. For the six zero-image stories, review the three scene-prompt suggestions per story, then create/approve real image assets and records through the authorized process; prompts are not assets.
5. Verify configured and generated piece counts from a current authorized source. Generate only after asset/content approvals; do not treat configured pieces as generated pieces.
6. After actual pieces exist, have a human reviewer validate scene/question fit and approve mappings using real identifiers. Recompute counts and coverage from a fresh source. Do not infer one-to-one coverage or invent keys/IDs.
7. Keep all current audit and question materials as drafts. Do not import or publish from these reports alone, and do not claim any story is playable or publishable.

## Source report index

Detailed reports (one per story): `story-01.md`, `story-02.md`, `story-03.md`, `story-04.md`, `story-05.md`, `story-06.md`, `story-07.md`, `story-08.md`, `story-09.md`, `story-10.md`, `story-11.md`, `story-12.md`, `story-13.md`, and `story-14.md` in this directory. This consolidated report summarizes those files and does not supersede them.
