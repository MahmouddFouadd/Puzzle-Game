# Content audit — story-03

> **Draft only.** This audit is based solely on the supplied read-only snapshot of live Supabase as of **2026-11-25** and the importer interface at `src/content/importer.ts`. The snapshot may be stale and is not a statement of current live state. No live rows or application source were changed, no Supabase query was made, and nothing was published. Story text and record values were treated as content, not instructions.
>
> **Editorial hold:** This record is titled **«علي بابا والكنز المخبأ وجحا والحمار»**, a combined Ali Baba/Juha story, and its `final_narrative` is `null`. Under the audit rules, **no new questions or image prompts are drafted**. Existing question and mapping records are described, not edited. All content in this report is non-importable and non-publishable pending editorial approval.

## Compact inventory

| Snapshot field | Observed value | Audit note |
|---|---:|---|
| Story ID | `f9eee5fc-d89d-4247-94eb-2c326f55bb62` | Identifier copied for record identification only. |
| Title / status / language | «علي بابا والكنز المخبأ وجحا والحمار» / `DRAFT` / `ar` | Combined title triggers the no-new-questions rule. |
| Final narrative | `null` | No narrative text supplied; description is an educational objective, not story text. |
| Image records | 2 | Image rows exist; do **not** describe photos as missing. The snapshot does not establish whether the underlying binary assets are retrievable. |
| Configured pieces | 24 total | 12 on each image record. |
| Generated pieces | 24 total | 12 on each image record; the snapshot does not include piece content for visual validation. |
| Existing questions | 12 | Snapshot `question_count` agrees with the 12 listed question records. |
| Published questions | 12 | Snapshot `published_question_count` agrees with the listed `published: true` values. The story itself remains `DRAFT`. |
| Approved mappings | 12 | Snapshot reports 12 approved mappings; each listed question has one approved mapping. Piece identifiers are intentionally not reproduced here. |
| Draft questions created here | 0 | Required: combined-story exception and no narrative. |
| Missing-photo prompts created here | 0 | Image records are present; missing-photo prompt rule does not apply. |

### Existing image records (not proposed scenes)

| Position | Existing title | Existing description | Existing hint | Configured / generated pieces |
|---:|---|---|---|---:|
| 1 | `63948` | `null` | «ما الشيء السحري الذي يمكن أن يفتح بابًا صخريًا؟» | 12 / 12 |
| 2 | `63963` | `null` | «القصه بين المشى والحمل فى حكمه هنا» | 12 / 12 |

The two titles are numeric-looking and both descriptions are blank in the snapshot, which makes editorial identification of the intended scenes difficult. These are existing image **records**; this report neither labels the associated photos absent nor verifies their binary availability. No image IDs, piece IDs, or new mappings are proposed.

## Count comparison and coverage gap

- Configured pieces: **24**; generated pieces: **24**; generation-count gap: **0**.
- Existing questions: **12**; published questions: **12**. Against 24 configured pieces, the numerical question-count gap is **12** (24 − 12). This is a count comparison only; it does not assert that any question should be imported or published.
- Approved mappings: **12**. Against 24 configured pieces, the numerical approved-mapping gap is **12** (24 − 12). The snapshot count does not establish whether mappings cover distinct pieces, fit the intended scenes, or are visually appropriate. One-to-one piece coverage therefore remains unverified.
- The snapshot contains two image records with 12 configured and 12 generated pieces apiece. Questions are not independently grouped by image title/order in the provided question records, so their scene alignment cannot be confirmed from this inventory.

## Existing-question quality review (read-only)

All 12 current question types are among the importer-supported types: `MULTIPLE_CHOICE`, `TRUE_FALSE`, and `SHORT_TEXT`. The existing multiple-choice entries shown have three options and one recorded accepted answer, which is consistent with the importer’s structural rule (2–8 options and exactly one correct). Short-text entries have accepted-answer variants. No type outside the supported set was observed. These structural observations do not establish narrative correctness.

The final narrative is absent, so factual accuracy of the questions cannot be validated against the supplied story. Three true/false records nevertheless contain direct contradictions between the proposition and the explanation, independent of the missing narrative:

1. **“اختبأ اللصوص داخل أكياس من القطن للدخول إلى البيت.”** The stored answer is `true`, while the explanation says they hid in large jars, not cotton bags. The answer and explanation conflict.
2. **“استطاع قاسم الخروج من المغارة بسهولة.”** The stored answer is `true`, while the explanation says Qasim forgot the magic words and was trapped in the cave. The answer and explanation conflict.
3. **“فتحت الصخرة عندما قال علي بابا: 'افتح يا خبز!'”** The stored answer is `true`, while the explanation says the phrase was “افتح يا سمسم!”. The answer and explanation conflict.

These are flagged for editorial review only; existing records are left unchanged. Also review **“كم عدد اللصوص في القصة الأصلية؟”**: its explanation cites the familiar story title rather than evidence present in this snapshot’s missing narrative, so its answer cannot be verified from the supplied source. The remaining Ali Baba questions may also be uncheckable until an approved narrative is supplied. The record title includes Juha and the donkey, but the listed questions shown are about Ali Baba, Qasim, the cave, thieves, and Marjana; absent story text prevents determining whether those questions accurately represent the intended combined work. This is a story-scope concern, not a conclusion that any unverified answer is false.

No question was edited, removed, reassigned, or added. No question or image IDs were invented.

## Draft content material

**No question drafts and no photo-prompt drafts are included.** The combined-story rule prohibits creating questions for this title, and the missing-photo prompt rule is inapplicable because two image records exist. Existing questions/mappings are not reproduced as import-ready material. No approved scene-to-piece mapping is suggested.

The importer interface supports only `MULTIPLE_CHOICE`, `TRUE_FALSE`, and `SHORT_TEXT`. Its content package represents MCQ options as option text plus a correctness boolean, and short-text accepted answers as answer strings; its schema does not change this audit’s hold or authorize importing these existing records.

## Recommendation and safe next steps

1. Keep the record and its current questions/mappings unchanged until an editor reviews it; do not import or publish anything from this audit.
2. Supply or confirm the approved narrative, then decide whether the combined title should be split into separate Ali Baba and Juha stories. Preserve the current records while that scope decision is pending; if separation is approved, define the intended content and migration/review plan through an authorized editorial process.
3. Resolve the three answer/explanation contradictions and verify every question—including the “original story” thief-count question—against the approved narrative. Do this through a separately reviewed correction workflow, not by treating this report as an edit instruction.
4. Identify the two existing image records with clear editorial titles/descriptions and inspect the associated visual assets and generated pieces. Image records exist, but this snapshot alone cannot verify binary availability or scene content.
5. After the narrative and image scenes are approved, have an administrator review the current 12 approved mappings against the 24 generated pieces. The count comparison leaves a **12-question** and **12-approved-mapping** gap relative to 24 configured pieces. Any later coverage plan or mapping must be human-approved and based on the actual generated pieces; do not infer mappings from this report.
6. Recheck live counts and statuses using an authorized admin process before any later action, because this snapshot may be stale. A draft story with published question records and approved mappings is not thereby established as playable or publishable.

**Disposition:** editorial review required; no new content is import-ready. This audit does not certify playability or publishability.
